package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class HelloController {


    public Text scr;
    public TextField txt1;
    public TextField txt2;
    public TextField txt3;
    public Label scr2;
    public Text scr3;
    public Text scr4;

    @FXML
    protected void On1btclick() {

      double txtt1=Double.parseDouble(txt1.getText());
     double txtt2=Double.parseDouble(txt2.getText());
    double txtt3=Double.parseDouble(txt3.getText());
        double delta=Math.pow(txtt1,2)-4*(txtt2*txtt3);
      scr.setText(String.valueOf(delta));
        scr3.setText(String.valueOf((-txtt2-Math.sqrt(delta))/(2*txtt1)));
        scr4.setText(String.valueOf((-txtt2+Math.sqrt(delta))/(2*txtt1)));
    }

    public void On2btclick(ActionEvent actionEvent) {
        double txtt1=Double.parseDouble(txt1.getText());
        double txtt2=Double.parseDouble(txt2.getText());
        double txtt3=Double.parseDouble(txt3.getText());
        scr2.setText(Math.sqrt(txtt1)+", "+Math.sqrt(txtt2)+", "+Math.sqrt(txtt3));
    }
}
package com.example.demo1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.json.JSONArray;
import org.json.JSONObject;
import org.mindrot.jbcrypt.BCrypt;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serial;
import java.util.ArrayList;

public class HelloController {
    public TextField login;
    public TextField email;
    public ChoiceBox<String> education;
    public Button loadData;
    public Button register;
    public ChoiceBox<String> language;
    public ChoiceBox<String> hobbys;
    public TextArea txtArea;
    public ImageView imgView;
    public PasswordField pass;
    public PasswordField rpass;
    public RadioButton male;
    public RadioButton female;
    public RadioButton unkn;

    public void initialize(){
        education.getItems().addAll("Primary", "Secondary", "Tertiary");
        language.getItems().addAll("English","Polish","German");
        hobbys.getItems().addAll("Music","Computers","Cars");
    }
    public void chng(){
        System.out.println(hashPassword((String) education.getValue()));
    }
    private String getGender(){
        if(male.isSelected()) {
            return "male";
        }
        else if(female.isSelected()) {
            return "female";
        }
        else if(unkn.isSelected()) {
            return "unknown";
        }
        return null;
    }
    private String hashPassword(String plainTextPassword) {
        return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt());
    }
    private void saveToFile(File file, String content) {
        try {
            PrintWriter printWriter=new PrintWriter(file);
            printWriter.write(content);
            printWriter.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void register(ActionEvent actionEvent) throws JsonProcessingException {
       /* FileChooser fileChooser=new FileChooser();
        File file=fileChooser.showSaveDialog(new Stage());
        if(file!=null) {
            saveToFile(file,);
        } */
        JSONObject jo = new JSONObject();
        jo.put("education", this.education.getValue());
        jo.put("language", this.language.getValue());
        jo.put("hobbys", this.hobbys.getValue());
        jo.put("email", this.email.getText());
        jo.put("login", this.login.getText());
        jo.put("gender",getGender());
        jo.put("pass", hashPassword(this.pass.getText()));
        jo.put("rpass", hashPassword(this.rpass.getText()));
        System.out.println(jo);
    }
}
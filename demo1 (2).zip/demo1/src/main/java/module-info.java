module com.example.demo1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires jbcrypt;
    requires com.fasterxml.jackson.databind;
    requires com.fasterxml.jackson.core;
    requires org.json;


    opens com.example.demo1 to javafx.fxml;
    exports com.example.demo1;
}
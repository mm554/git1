package com.example.demo1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.json.JSONArray;
import org.json.JSONObject;
import org.mindrot.jbcrypt.BCrypt;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class HelloController {
    public  CheckBox A1;
    public  CheckBox B2;
    public  CheckBox A2;
    public  CheckBox C1;
    public  CheckBox B1;
    public  CheckBox C2;
    public TextField login;
    public TextField email;
    public ChoiceBox<String> education;
    public Button loadData;
    public Button register;
    public ChoiceBox<String> language;
    public ChoiceBox<String> hobbys;
    public TextArea txtArea;
    public ImageView imgView;
    public PasswordField pass;
    public PasswordField rpass;
    public RadioButton male;
    public RadioButton female;
    public RadioButton unkn;

    public void initialize(){
        education.getItems().addAll("Primary", "Secondary", "Tertiary");
        language.getItems().addAll("English","Polish","German");
        hobbys.getItems().addAll("Music","Computers","Cars");
    }
    public void chng(){
        System.out.println(hashPassword((String) education.getValue()));
    }
    private String getGender(){
        if(male.isSelected()) {
            return "male";
        }
        else if(female.isSelected()) {
            return "female";
        }
        else if(unkn.isSelected()) {
            return "unknown";
        }
        return null;
    }
    private String getLangLevel(){
        if(A1.isSelected()) {
            return "A1";
        }
        else if(A2.isSelected()) {
            return "A2";
        }
        else if(B1.isSelected()) {
            return "B1";
        }
        else if(B2.isSelected()) {
            return "B2";
        }
        else if(C1.isSelected()) {
            return "C1";
        }
        else if(C2.isSelected()) {
            return "C2";
        }
        return null;
    }
    private String hashPassword(String plainTextPassword) {
        return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt());
    }
    private void saveToFile(File file, String content) {
        try {

            FileWriter fr=new FileWriter(file,true);
            BufferedWriter br = new BufferedWriter(fr);
            PrintWriter pr = new PrintWriter(br);

            pr.println(content);
            pr.close();
            br.close();
            fr.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
public void loadData(){
        FileChooser fch=new FileChooser();
        File fl=fch.showOpenDialog(new Stage());
        try {
            Scanner scan = new Scanner(fl);
            while(scan.hasNextLine()) {
                txtArea.appendText(scan.nextLine());
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
}
    public void register(ActionEvent actionEvent) throws JsonProcessingException {
        FileChooser fileChooser=new FileChooser();
        File file=fileChooser.showSaveDialog(new Stage());
        if(file!=null) {
            JSONObject jo = new JSONObject();
            jo.put("education", this.education.getValue());
            jo.put("language", this.language.getValue());
            jo.put("langlevel", this.getLangLevel());
            jo.put("hobbys", this.hobbys.getValue());
            jo.put("email", this.email.getText());
            jo.put("login", this.login.getText());
            jo.put("gender",getGender());
            jo.put("pass", hashPassword(this.pass.getText()));
            jo.put("rpass", hashPassword(this.rpass.getText()));
            saveToFile(file, String.valueOf(jo));
            System.out.println(jo);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.getDialogPane().setContentText("Pomyślnie zapisano uzytkownika do pliku");
            alert.showAndWait();
        }


    }
}